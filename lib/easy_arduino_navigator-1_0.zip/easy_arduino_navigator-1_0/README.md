# easy_arduino_navigator
library for solving problems with a maze according to the rule of the left/right hand
