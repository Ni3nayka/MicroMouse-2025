# AVOCADO_esp
esp lib for Arduino IDE for wifi communication with PC

### Support board:
1) ESP8266
2) ESP32
